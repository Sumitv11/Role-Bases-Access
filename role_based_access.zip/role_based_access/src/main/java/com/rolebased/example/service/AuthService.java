package com.rolebased.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.rolebased.example.dto.AuthResponse;
import com.rolebased.example.dto.LoginRequest;
import com.rolebased.example.dto.SignupRequest;
import com.rolebased.example.dto.UnifiedResponse;
import com.rolebased.example.entity.User;
import com.rolebased.example.exception.ApprovalPendingException;
import com.rolebased.example.exception.ResourceAlreadyExistsException;
import com.rolebased.example.exception.ResourceNotFoundException;
import com.rolebased.example.repository.UserRepository;
import com.rolebased.example.util.CommonHelper;
import com.rolebased.example.util.JwtHelper;

@Service
public class AuthService {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtHelper jwtHelper;

	@Autowired
	private MyUserDetailService userDetailsService;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CommonHelper commonHelper;

	public UnifiedResponse<User> register(SignupRequest registerUser) {
		if (userRepository.existsByEmail(registerUser.getEmail())) {
			throw new ResourceAlreadyExistsException(
					"User already exists with this email . Please try with other credentials.");
		}

		User user = new User();
		user.setName(registerUser.getName());
		user.setEmail(registerUser.getEmail());
		user.setPassword(passwordEncoder.encode(registerUser.getPassword()));
		user.setRole(registerUser.getRole());
		user.setIsDeleted(false);
		return commonHelper.returnUnifiedCREATED("Registered successfully", userRepository.save(user));
	}

	public UnifiedResponse<AuthResponse> login(LoginRequest authRequest) {
		findUserByEmail(authRequest.getEmail());

		if (!passwordEncoder.matches(authRequest.getPassword(), findUserByEmail(authRequest.getEmail()).getPassword()))
			throw new ResourceNotFoundException("Invalid credentials please enter the valid email and password");

		if (findUserByEmail(authRequest.getEmail()).getIsDeleted() != null
				&& findUserByEmail(authRequest.getEmail()).getIsDeleted() == true)
			throw new ResourceNotFoundException("You have been blocked by the admin");

		if (findUserByEmail(authRequest.getEmail()).getRole().name().equals("Educator")
				&& (!userRepository.isApprovedByEmail(authRequest.getEmail())) && passwordEncoder
						.matches(authRequest.getPassword(), findUserByEmail(authRequest.getEmail()).getPassword()))
			throw new ApprovalPendingException("Approval is pending from the admin side please wait");

		authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(authRequest.getEmail(), authRequest.getPassword()));
		UserDetails userDetails = userDetailsService.loadUserByUsername(authRequest.getEmail());
		String token = jwtHelper.generateToken(userDetails);

		User user = findUserByEmail(authRequest.getEmail());

		return commonHelper.returnUnifiedOK("Logged in successfully",
				new AuthResponse(token, user.getRole().name(), user.getIsApproved()));
	}

	public User findUserByEmail(String email) {
		return userRepository.findByEmail(email).orElseThrow(
				() -> new UsernameNotFoundException("Invalid credentials please enter the valid email and password"));
	}
}
