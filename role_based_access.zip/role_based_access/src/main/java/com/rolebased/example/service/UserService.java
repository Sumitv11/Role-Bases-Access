package com.rolebased.example.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.rolebased.example.dto.AdminProfileDataResponse;
import com.rolebased.example.dto.EducatorProfileDataResponse;
import com.rolebased.example.dto.PageResponse;
import com.rolebased.example.dto.UnifiedResponse;
import com.rolebased.example.dto.UpdateUserRequest;
import com.rolebased.example.entity.User;
import com.rolebased.example.enums.Role;
import com.rolebased.example.exception.ResourceNotFoundException;
import com.rolebased.example.repository.CategoryRepository;
import com.rolebased.example.repository.QuestionRepository;
import com.rolebased.example.repository.QuizRepository;
import com.rolebased.example.repository.UserRepository;
import com.rolebased.example.util.CommonHelper;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private CommonHelper commonHelper;

	public User getUserByEmail(String email) {
		return userRepository.findByEmail(email)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
	}

	public User getUserInfoUsingTokenInfo() {
		String username = (String) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		return getUserByEmail(username);
	}

	public UnifiedResponse<User> getUserInformation() {
		return commonHelper.returnUnifiedOK("Fetched user", getUserInfoUsingTokenInfo());
	}

	public UnifiedResponse<EducatorProfileDataResponse> getEducatorProfileInformation() {
		User creator = getUserInfoUsingTokenInfo();
		return commonHelper.returnUnifiedOK("Fetched data", new EducatorProfileDataResponse(creator.getName(), creator.getRole()));
	}

	public UnifiedResponse<AdminProfileDataResponse> getAdminProfileInformation() {
		Long totalUsers = userRepository.countTotalUsers();
		return commonHelper.returnUnifiedOK("Fetched data", new AdminProfileDataResponse(totalUsers));
	}

	
}
