package com.rolebased.example.repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.rolebased.example.entity.User;
import com.rolebased.example.enums.Role;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	@Query("SELECT u FROM User u WHERE u.email = :email AND (u.isDeleted = false OR u.isDeleted IS NULL)")
	Optional<User> findByEmail(@Param("email") String email);

	boolean existsByEmail(String email);

	@Query("SELECT CASE WHEN u.isApproved = true THEN true ELSE false END FROM User u WHERE u.email = :email AND (u.isDeleted = false OR u.isDeleted IS NULL)")
	boolean isApprovedByEmail(@Param("email") String email);

	Optional<User> findById(Long id);

	@Query("SELECT COUNT(u) FROM User u WHERE (u.isDeleted = false OR u.isDeleted IS NULL) AND u.role IN ('Educator', 'Student')")
	Long countTotalUsers();
}