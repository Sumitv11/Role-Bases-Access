package com.rolebased.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rolebased.example.dto.AuthResponse;
import com.rolebased.example.dto.LoginRequest;
import com.rolebased.example.dto.SignupRequest;
import com.rolebased.example.dto.UnifiedResponse;
import com.rolebased.example.entity.User;
import com.rolebased.example.service.AuthService;
import com.rolebased.example.util.ResponseBuilder;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
	@Autowired
	private AuthService authService;

	@PostMapping("/register")
	public ResponseEntity<UnifiedResponse<User>> register(@Valid @RequestBody SignupRequest registerUser) {
		return ResponseBuilder.buildResponse(HttpStatus.CREATED, authService.register(registerUser));
	}

	@PostMapping("/login")
	public ResponseEntity<UnifiedResponse<AuthResponse>> login(@Valid @RequestBody LoginRequest authRequest) {
		return ResponseBuilder.buildOKResponse(authService.login(authRequest));
	}
}
