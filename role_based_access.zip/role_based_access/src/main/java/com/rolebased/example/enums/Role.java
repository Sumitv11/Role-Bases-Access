package com.rolebased.example.enums;

public enum Role {
	Educator,Admin
}