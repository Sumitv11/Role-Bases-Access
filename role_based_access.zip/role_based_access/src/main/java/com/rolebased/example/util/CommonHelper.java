package com.rolebased.example.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.rolebased.example.dto.PageResponse;
import com.rolebased.example.dto.UnifiedResponse;

@Service
public class CommonHelper {


	public <T> UnifiedResponse<T> returnUnifiedOK(String message, T data) {
		return new UnifiedResponse<>(Codes.OK, message, data);
	}

	public <T> UnifiedResponse<T> returnUnifiedCREATED(String message, T data) {
		return new UnifiedResponse<>(Codes.CREATED, message, data);
	}

	public Pageable makePageReq(int page, int size) {
		return PageRequest.of(page, size);
	}

}