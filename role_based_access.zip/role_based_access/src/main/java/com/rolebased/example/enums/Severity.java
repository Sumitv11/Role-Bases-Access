package com.rolebased.example.enums;

public enum Severity {
	Hard, Medium, Beginner,
}
