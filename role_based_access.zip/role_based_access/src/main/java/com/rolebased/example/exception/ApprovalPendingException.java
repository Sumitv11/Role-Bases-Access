package com.rolebased.example.exception;

public class ApprovalPendingException extends RuntimeException {
	public ApprovalPendingException(String message) {
		super(message);
	}
}