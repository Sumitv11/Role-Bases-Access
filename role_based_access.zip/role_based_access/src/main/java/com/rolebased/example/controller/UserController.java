package com.rolebased.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.rolebased.example.dto.AdminProfileDataResponse;
import com.rolebased.example.dto.EducatorProfileDataResponse;
import com.rolebased.example.dto.PageResponse;
import com.rolebased.example.dto.UnifiedResponse;
import com.rolebased.example.dto.UpdateUserRequest;
import com.rolebased.example.entity.User;
import com.rolebased.example.enums.Role;
import com.rolebased.example.service.UserService;
import com.rolebased.example.util.CommonHelper;
import com.rolebased.example.util.ResponseBuilder;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	CommonHelper commonHelper;

	@GetMapping("/currentUser")
	public ResponseEntity<UnifiedResponse<User>> getUserInformation() {
		return ResponseBuilder.buildOKResponse(userService.getUserInformation());
	}

	@GetMapping("/educatorProfileData")
	@PreAuthorize("hasRole('Educator')")
	public ResponseEntity<UnifiedResponse<EducatorProfileDataResponse>> getEducatorProfileInformation() {
		return ResponseBuilder.buildOKResponse(userService.getEducatorProfileInformation());
	}

	@GetMapping("/adminProfileData")
	@PreAuthorize("hasRole('Admin')")
	public ResponseEntity<UnifiedResponse<AdminProfileDataResponse>> getAdminProfileInformation() {
		return ResponseBuilder.buildOKResponse(userService.getAdminProfileInformation());
	}

	
}
