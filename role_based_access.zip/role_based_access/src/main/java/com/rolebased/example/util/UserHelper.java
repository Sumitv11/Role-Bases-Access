package com.rolebased.example.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rolebased.example.entity.User;
import com.rolebased.example.service.UserService;

@Service
public class UserHelper {
	
	@Autowired
	UserService userService;

	public User getUser() {
		return userService.getUserInfoUsingTokenInfo();
	}
}
